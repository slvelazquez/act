/* 
 * File:   ADC.h
 * Author: iProf
 *
 * Created on 15 de septiembre de 2023, 09:11 AM
 */

#ifndef ADC_H
#define	ADC_H

#include <xc.h>

void ADC_Init();
int ADC_Get_Value(char ch);

#endif	/* ADC_H */

