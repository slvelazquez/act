/* 
 * File:   config.h
 * Author: iProf
 *
 * Created on 20 de septiembre de 2023, 02:16 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 20000000UL

#endif	/* CONFIG_H */

