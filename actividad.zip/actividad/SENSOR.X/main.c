#include <xc.h>
#include <stdio.h>
#include "config.h"
#include "LCD_LIB.h"
#include "ADC.h"

char strLCD[20] = " ";

int conver;
float lm35, mcp, ldr;
int tem;
int conv_act,conv_min,resp_min,conv_max,resp_max;
// Variables de mapeo para el LM35
int conv_act_lm35, conv_min_lm35, conv_max_lm35;
float resp_min_lm35, resp_max_lm35;



    float map(int conv_act, int conv_min, float resp_min, int conv_max, float resp_max) {
     tem=(conv_act - conv_min) * (resp_max - resp_min) / (conv_max - conv_min) + resp_min;
}

void main(void) {
    // CONFIGURAMOS LA SE�ALES DE RELOJ
    OSCCON = 0x38; // OSC EXT HS
    //OSCCON  = 0x72; // OSC INT
    OSCTUNE = 0x00;
    BORCON = 0x00;

    ANSELAbits.ANSA0 = 1;
    ANSELAbits.ANSA1 = 1;
    ANSELAbits.ANSA2 = 1;

    TRISAbits.TRISA0 = 1;
    TRISAbits.TRISA1 = 1;
    TRISAbits.TRISA2 = 1;

    ADC_Init();
    LCD_Init();
    LCD_Cmd(_LCD_CURSOR_OFF);

    // Configuraci�n de mapeo para LM35
    conv_min_lm35 = 0;       // Valor m�nimo del ADC para LM35
    conv_max_lm35 = 1023;    // Valor m�ximo del ADC para LM35
    resp_min_lm35 = 0.0;    // Temperatura m�nima para LM35 (en grados Celsius)
    resp_max_lm35 = 100.0;  // Temperatura m�xima para LM35 (en grados Celsius)

    while (1) {
       conver = ADC_Get_Value(2);
        ldr = (100.0/1023.0)*conver;
        sprintf(strLCD,"LDR: %5.1f", ldr);
        LCD_Write_Text(3,1,strLCD);
        LCD_Write_Cp('%');

        conver = ADC_Get_Value(1);
        conv_act_lm35 = conver;
        lm35 = (conv_act_lm35* conv_min_lm35),  (conv_max_lm35 - resp_min_lm35)+ resp_max_lm35;

        sprintf(strLCD, "LM35: %0.1f", lm35);
        LCD_Write_Text(1, 1, strLCD);

      

        __delay_ms(200);
    }
    return;
}
